🤖✨ IMRAN-BOT

<div align="center"> 
  <a href="https://readme-typing-svg.demolab.com/demo/?color=4B21F7&background=7C6F7100&lines=SPAIDO-BOT;Multi+Device+Whatsapp+Bot;Made+With+Love+By+Spaido+Hacks" />
  </a> 
</div> <div align="center"> 
  <img src="https://raw.githubusercontent.com/ahmadtech12/IMRAN-BOT/main/assets/june_repo.jpg" alt="IMRAN BOT" height="300">
</div>
---

> 🌟 DEPLOYMENT GUIDE 🌟



🚀 1. Fork the Repository

Click the button below to fork IMRAN-BOT repository to your GitHub account.

<p align="left">
  <a href="https://github.com/bigspaido/SPAIDO-BOT/forks">
    <img src="https://img.shields.io/badge/Fork%20Repo-100000?style=for-the-badge&logo=github&logoColor=white&labelColor=black&color=darkgreen" alt="FORK REPO"/>
  </a>
</p>🧾 2. No Need for Manual Pair Code Setup!

> 🧠 You don't need to visit any external pairing link!



✅ When you run your bot on platforms like bot-hosting.net or a VPS, the terminal will say put your number, enter your number and you'll receive pair code.  !

copy and paste that code in your Whatsapp and boom 💥 your bot is now connected. 
No need to go anywhere else. . 😄

💾 3. Download Bot Zip

<p align="left">
  <a href="https://github.com/ahmadtech12/IMRAN-BOT/archive/refs/heads/main.zip">
    <img src="https://img.shields.io/badge/Download-Zip-blueviolet?style=for-the-badge&logo=github" alt="Download ZIP"/>
  </a>
</p>🛠️ 4. Deployment Help

Watch the tutorial and deploy your bot easily.

<div align="left">
  <a href="https://youtu.be/aZMUw_YkcwI?si=xxHilfRhsPUM3-fW">
    <img src="https://img.shields.io/badge/TUTORIAL-red?style=for-the-badge&logo=youtube" alt="YouTube Tutorial"/>
  </a><br>
  <a href="https://bot-hosting.net/?aff=1068419752923508776">
    <img src="https://img.shields.io/badge/Bothosting%20Panel-green?style=for-the-badge" alt="BOT HOSTING PANEL"/>
  </a>
</div>
---



🧩 Features

💬 WhatsApp Multi-device support

🧠 Auto replies, menus, fun commands

📁 Group moderation tools

🤖 Fully customizable bot



---

> Made with ❤️ by Imran khan — Follow and star the repo if you enjoy it!



