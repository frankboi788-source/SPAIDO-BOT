const settings = {
  packname: '✨SPAIDO BOT✨',
  author: '👑 SPAIDO Hacks',
  botName: '🤖 SPAIDO BOT',
  botOwner: 'SPAIDO Hacks', // Your name
  ownerNumber: '639691465580', // Set your number here without + symbol.
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: 'public', // can be 'public' or 'private'
  description: '💬 A powerful fun WhatsApp MD bot built with ❤️ by SPAIDO Hacks.',
  version: '2.0.0',
};

module.exports = settings;
